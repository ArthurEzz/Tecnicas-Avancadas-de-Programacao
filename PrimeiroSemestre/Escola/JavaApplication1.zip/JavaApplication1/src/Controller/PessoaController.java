package Controller;

import Model.Pessoa;

public class PessoaController {
    
    public boolean efetuaGravacao (String nome, int idade){
      Pessoa p = new Pessoa();
      p.setNome(nome);
      p.setIdade(idade);
      
      
    return p.gravar();
    }
    
}
